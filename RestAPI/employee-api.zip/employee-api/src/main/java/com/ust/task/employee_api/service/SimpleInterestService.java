package com.ust.task.employee_api.service;

import org.springframework.stereotype.Service;

@Service
public class SimpleInterestService {
    public double calculateSimpleInterest(double principal, double rate, double time) {
        return (principal * rate * time) / 100;
    }
}
