package com.ust.task.employee_api.service;



import com.ust.task.employee_api.repository.EmpRepo;
import com.ust.task.model.Employee;
import com.ust.task.repository.EmpRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class empServiceImpl implements empservice {

    private final EmpRepo empRepo;

    @Autowired
    public empServiceImpl(EmpRepo empRepo) {
        this.empRepo = empRepo;
    }

    @Override
    public String createEmp(Employee employee) {
        empRepo.save(employee);
        return "Success";
    }

    @Override
    public String updateEmp(Employee employee) {
        empRepo.save(employee);
        return "Success";
    }

    @Override
    public Employee getEmp(String id) {
        return empRepo.findById(id).orElse(null);
    }
}
