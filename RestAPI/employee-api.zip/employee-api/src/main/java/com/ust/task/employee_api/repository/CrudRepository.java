package com.ust.task.employee_api.repository;

public interface CrudRepository<T, T1> {
}
