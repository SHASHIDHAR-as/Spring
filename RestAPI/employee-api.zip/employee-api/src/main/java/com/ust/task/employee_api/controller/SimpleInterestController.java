package com.ust.task.controller;

import com.ust.task.employee_api.service.SimpleInterestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/interest")
public class SimpleInterestController {

    @Autowired
    private SimpleInterestService simpleInterestService;

    @GetMapping("/calculate")
    public String calculateSimpleInterest(@RequestParam double principal, @RequestParam double rate, @RequestParam double time) {
        double interest = simpleInterestService.calculateSimpleInterest(principal, rate, time);
        return "Simple Interest: " + interest;
    }
}
