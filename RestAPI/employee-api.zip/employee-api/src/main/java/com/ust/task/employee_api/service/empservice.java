package com.ust.task.employee_api.service;
import com.ust.task.model.Employee;

public interface empservice {
    String createEmp(Employee employee);
    String updateEmp(Employee employee);
    Employee getEmp(String id);
}
