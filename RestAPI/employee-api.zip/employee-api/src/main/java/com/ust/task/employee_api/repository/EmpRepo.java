package com.ust.task.employee_api.repository;



import com.ust.task.model.Employee;
import org.springframework.data.repository.CrudRepository;

public interface EmpRepo extends CrudRepository<Employee, String> {
}
