
public class City {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String cityname[]= {"Bengaluru","Mumbai","Hyderabad","Vizag"};
		
		for(String s:cityname) {
			System.out.println(s.charAt(0));
		}
		for(String s:cityname) {
			System.out.println(s.length());
		}
	}

}
