package Encapsulation;
import java.util.*;

public class Proj1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Data a=new Data(10);
//		System.out.println(a.getN());
//		a.setName("shashi");
//		System.out.println(a);
//		
//		Data a2=new Data(10);
//		a2.setName("shashi");
//		System.out.println(a.equals(a2));
		
//		int x=10;
//		
//		Integer a=Integer.valueOf(x);
//		
//		x=a.intValue();
//		
//		System.out.println(x);
//		
//		String s="123";
//		int n=Integer.parseInt(s);
//		System.out.println(++n);
//		
//		String hs=String.valueOf(n);
//		System.out.println(hs.charAt(1));
		
//		HashMap<Integer,Data> hm=new HashMap<>; 
		HashMap<Integer,Integer>h=new HashMap<>();
		
	}

}
