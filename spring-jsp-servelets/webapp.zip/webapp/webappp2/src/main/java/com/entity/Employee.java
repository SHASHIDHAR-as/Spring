package com.entity;




public class Employee{
    private int empId;
    private String name;
    private float salary;

    
//    public Employee(){
//        empId=111;
//        name="not known";
//        salary=0;
//    }
//    
//    public Employee(int empId,String name){
//        this.empId=empId;
//        this.name=name;
//        salary=10000;
//    }
    
    public Employee(int empId,String name,float salary){
        this.empId=empId;
        this.name=name;
        this.salary=salary;
    }
    
//    public Employee(int empId, String name, float salary, String[] skills) {
//		super();
//		this.empId = empId;
//		this.name = name;
//		this.salary = salary;
//		this.skills = skills;
//	}

	public void display(){
        System.out.println(empId);
        System.out.println(name);
        System.out.println(salary);
    }
    
    public int getEmpId(){
        return empId;
    }
    
    public void setEmpId(int empId){
        this.empId=empId;
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String name){
        this.name=name;
    }
    
    public float getSalary(){
        return salary;
    }
    
    public void setSalary(float salary){
        if(salary<10000)
        this.salary=10000;
    }
    
    
    
    
    
    
}